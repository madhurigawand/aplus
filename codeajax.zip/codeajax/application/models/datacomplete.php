<?php
class Datacomplete extends CI_Model{
    
    public function GetRow($keyword) {        
        $this->db->order_by('id', 'DESC');
        $this->db->like("name", $keyword);
         //$this->db->or_like('iso',$keyword,'after'); 
        return $this->db->get('autocomplete')->result_array();
    }
}